// Generated
window.__HPC_CONFIG = {"school_id":2,"school_name":"School","udise_code":"","token":"test","server_url":"https:\/\/ctetmonktest.fun"};
