// HPC Assist pre-configuration (generated for )
window.__HPC_CONFIG = {
    "school_id": 0,
    "school_name": "",
    "udise_code": "",
    "token": "",
    "server_url": "http://localhost"
};
